
public class Bus {
	public String id;
	public int stop;
	
	public Bus(String id, int stop) {
		this.id = id;
		this.stop = stop;
	}
}

